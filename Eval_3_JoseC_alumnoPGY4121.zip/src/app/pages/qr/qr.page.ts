import { Component } from '@angular/core';
import { MenuController } from '@ionic/angular';


@Component({
  selector: 'app-qr',
  templateUrl: './qr.page.html',
  styleUrls: ['./qr.page.scss'],
})
export class QRPage {
  mostrarImagen: boolean = false;
    content_visibility: string = 'visible'; // Declare content_visibility property
    qrData: string = '';
    // ...rest of your component code
  
   // Aquí se almacenará el contenido del código QR generado
 

  constructor(private menu: MenuController) {}

  verMenu() {
    this.menu.open('first');
  }

  async startScan() {
    try {
      // Aquí se puede colocar la lógica para obtener datos de un escáner de código QR
      // Podrías utilizar alguna librería como '@ionic-native/barcode-scanner' para escanear
      // Por ejemplo, con '@ionic-native/barcode-scanner':
      // const data = await this.barcodeScanner.scan();
      
      // En este ejemplo, simularemos que se obtiene algún dato del escáner
      const scannedData = 'https://www.ejemplo.com'; // Ejemplo de dato obtenido del escáner
      
      // Asignamos el dato escaneado para generar el código QR
      this.qrData = scannedData;
      this.mostrarImagen = true; // Mostramos la imagen del código QR
    } catch (error) {
      console.error('Error al escanear:', error);
    }
  }
}



    /*try {
      const courses = await this.db.getCollection('Clases').toPromise();
      courses.forEach(course => this.clases.push(course));
    } catch (err) {
      console.error(err);
    }
    console.log(this.clases);
  }
}
    /*console.log(this.clases);
          console.log(this.clases);
          let fechas: any = this.clases.fechas;
          let asistencia: any = this.clases.asistencia;
          let data: any = {
            asignatura: this.code,
            fechas: fechas.concat(new Date()),
            asistencia: asistencia + 1,
          }
          console.log(data);
          this.db.setDoc(data, 'Clases', this.code).then((res) => {
            console.log('Asistencia añadida');
          })
          console.log('Class exists, assitance added')

        }
      else{
        //if dont existe create a new class on firebase
        let fechas: any = [new Date()];
        this.db.createDoc({
          asignatura: this.code,
          fechas: fechas,
          asistencia: 1,
        }, 'Clases', this.code);
        console.log('Class created');
      }
    }

  }
  
  





  /*this.database.createDoc(data).then((res) => {
    console.log('se a creado correctamente',res);
    this.animacion.showLoading;
    this.animacion.presentToast('Ha quedado presente');
    
  })*/








