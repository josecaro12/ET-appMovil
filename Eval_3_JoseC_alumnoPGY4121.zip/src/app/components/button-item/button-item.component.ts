import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-item',
  templateUrl: './button-item.component.html',
  styleUrls: ['./button-item.component.scss'],
})
export class ButtonItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
